package com.example.madsemesterproject;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.View;
import android.view.ViewGroup;
import androidx.fragment.app.Fragment;
import androidx.core.app.ActivityCompat;

public class fragment_menu {
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        return inflater.inflate(R.layout.fragment_layout, container, false);
        setHasOptionsMenu(true);

    }

    //Adding Menu Method.
    @Override
    public void onCreateOptionsMenu(Menu menu, MenuInflater inflater) {
        inflater.inflate(R.menu.other_menu, menu);
       // super.onCreateOptionsMenu(menu, inflater);
       ;
    }

}
